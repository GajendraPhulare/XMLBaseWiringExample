package WiringBeans3.Test3;

public interface CompactDisc {
	void play();

}
