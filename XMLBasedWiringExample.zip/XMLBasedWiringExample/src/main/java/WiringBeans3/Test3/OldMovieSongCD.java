package WiringBeans3.Test3;

import java.util.List;

public class OldMovieSongCD implements CompactDisc {
	private String title;
	private String artist;
	private List<String> trackList;
	
	
	
	public OldMovieSongCD() {
		
		}
	
	public OldMovieSongCD(String title, String artist,List<String> trackList) {
	this.title = title;
	this.artist = artist;
	this.trackList=trackList;
	}
	
	

	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Playing song 1.....");
		System.out.println("title....."+this.title);
		System.out.println("artist....."+this.artist);
		System.out.println("trackList....."+this.trackList);
	}

}
