package WiringBeans3.Test3;

public interface CDPlayer {
	
	void startPlayer() ;

}
