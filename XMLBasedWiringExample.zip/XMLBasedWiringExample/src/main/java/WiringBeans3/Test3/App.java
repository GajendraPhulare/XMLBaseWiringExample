package WiringBeans3.Test3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import WiringBeans3.Test3.SonyCDPlayer;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext applicationContext=new  FileSystemXmlApplicationContext("context.xml");
    
    CDPlayer sonycdplayer=(CDPlayer)applicationContext.getBean("cdPlayer");
    sonycdplayer.startPlayer();
    }
}
