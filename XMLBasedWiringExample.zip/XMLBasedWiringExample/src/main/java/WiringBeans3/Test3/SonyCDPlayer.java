package WiringBeans3.Test3;

public class SonyCDPlayer implements CDPlayer {
	
	CompactDisc cd;

	
	SonyCDPlayer(){
		
		
	}
	
SonyCDPlayer(CompactDisc cd){
		this.cd=cd;
		
	}
	
	public void startPlayer() {
		// TODO Auto-generated method stub
		
		System.out.println("Player started....");
this.cd.play();
	}

}
